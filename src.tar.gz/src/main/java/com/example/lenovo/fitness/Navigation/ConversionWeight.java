package com.example.lenovo.fitness.Navigation;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lenovo.fitness.R;

/**
 * Created by lenovo on 8/9/17.
 */

public class ConversionWeight extends AppCompatActivity {
    Toolbar t_bar;
    Spinner spinner_1,spinner_2;
    EditText Enter_value;
    TextView Set_Result;
    private double value,answer;
    private int flag1,flag2,flag3,flag4;
    private double kg=1.0,lbs=2.20462;
    Button b1;

    java.text.DecimalFormat two = new java.text.DecimalFormat("#0.00");

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.conversionweight);
        Displaytoolbar();
        Displayspinner();
        calculateConversion();

    }

    public double kg_to_lbs(){
        return answer=value*lbs;
    }
    public double lbs_to_kg(){
        return answer=(value*kg)/lbs;
    }

    private void AcceptData() {

        try{
            value=Double.parseDouble(Enter_value.getText().toString());
            answer=value;
        }catch (NumberFormatException e){
            Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT);
            e.printStackTrace();
        }
    }


    private void calculateConversion() {

        Enter_value=(EditText)findViewById(R.id.Quantity);
        Set_Result=(TextView)findViewById(R.id.SetResult2);
        b1=(Button)findViewById(R.id.calculate);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AcceptData();
                Displayspinner();


                if(flag1==1&&flag4==1)kg_to_lbs();
                if(flag3==1&&flag2==1)lbs_to_kg();

                Set_Result.setText(two.format(answer));

            }
        });
    }
    private void Displayspinner() {
        spinner_1=(Spinner)findViewById(R.id.spinner1);
        spinner_2=(Spinner)findViewById(R.id.spinner2);

        ArrayAdapter arrayadapter=ArrayAdapter.createFromResource
                (this,R.array.units1,android.R.layout.simple_spinner_dropdown_item);

        spinner_1.setAdapter(arrayadapter);
        spinner_2.setAdapter(arrayadapter);
        arrayadapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);


        spinner_1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override

            public void onItemSelected(AdapterView<?> parent, View view, int choice, long id) {

                //use choice value
                switch (choice){

                    case 0:
                       flag1=1;
                        break;

                    case 1:
                       flag2=1;
                        break;

                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        }); // on clicklistner of spinner1


        spinner_2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override

            public void onItemSelected(AdapterView<?> parent, View view, int choice, long id) {

                //use postion value
                switch (choice){

                    case 0:
                        flag3=1;
                        break;

                    case 1:
                        flag4=1;
                        break;

                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        }); // on clicklistner of spinner2
    }

    private void Displaytoolbar() {
        t_bar=(Toolbar)findViewById(R.id.included);
        setSupportActionBar(t_bar);

        if(getSupportActionBar()!=null){

            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle("Converter");
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
