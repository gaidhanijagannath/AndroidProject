package com.example.lenovo.fitness.Arm_Workout;

import android.content.Intent;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.example.lenovo.fitness.Congratulation;
import com.example.lenovo.fitness.R;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import at.markushi.ui.CircleButton;

public class plank extends AppCompatActivity {
    Toolbar t_bar;
    TextView t_view;
    CircleButton Start;
    VideoView view;
    int stopPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plank);
        PlayVideo();
        ShowToolBar();
        CardDisplay();
        ButtonClick();
    }

    private void PlayVideo() {


        view = (VideoView)findViewById(R.id.planks);
        String path = "android.resource://" + getPackageName() + "/" + R.raw.plankv;
        view.setVideoURI(Uri.parse(path));
        view.start();


        view.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                mp.setLooping(true);
            }
        });
    }

    @Override
    public void onPause() {

        super.onPause();
        stopPosition = view.getCurrentPosition(); //stopPosition is an int
        view.pause();
    }
    @Override
    public void onResume() {
        super.onResume();

        view.seekTo(stopPosition);
        view.start(); //Or use resume() if it doesn't work. I'm not sure
    }

    private void ButtonClick() {

        Start=(CircleButton)findViewById(R.id.button_plank);

        Start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity();
                Intent intent=new Intent(plank.this, Congratulation.class);
                startActivity(intent);
            }
        });


    }

    private void CardDisplay() {
        t_view=(TextView) findViewById(R.id.planks_txtview);

        Typeface custom_font=Typeface.createFromAsset(getApplicationContext().getAssets(),
                "fonts/PAPL_.ttf");
        t_view.setTypeface(custom_font);

        String DataRead="";
        StringBuffer sbuffer=new StringBuffer();
        InputStream is=this.getResources().openRawResource(R.raw.planks);
        BufferedReader br=new BufferedReader(new InputStreamReader(is));

        if(is!=null){

            try{

                while((DataRead=br.readLine())!=null){
                    sbuffer.append(DataRead+"\n");
                }
                t_view.setText(sbuffer);
                is.close();

            }catch (Exception e){e.printStackTrace();}
        }

    }
    private void ShowToolBar(){
        t_bar=(Toolbar)findViewById(R.id.include_planks);
        setSupportActionBar(t_bar);

        if(getSupportActionBar()!=null){

            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle("Planks");
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onBackPressed() {

        finishAffinity();
        Intent intent=new Intent(getApplicationContext(),ArmWorkout.class);
        startActivity(intent);
    }
}
