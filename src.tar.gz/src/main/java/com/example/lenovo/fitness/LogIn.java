package com.example.lenovo.fitness;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LogIn extends AppCompatActivity {

    private Button bt_login;
    private TextView Link_signup;
    private EditText email,passaword;
    private String email_temp,password_temp,CheckPass;


    //databasehelper calls for checking password
    DatabaseHelper db_helper=new DatabaseHelper(LogIn.this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        CheckLoginStatus();
        validateLogIn();
        GoToSignup();


    }

    public boolean Validate(){

        boolean valid=true;
        if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email_temp).matches()){
            email.setError("Enter a valid email address");
            valid=false;
        }else{
            email.setError(null);
        }

        if(password_temp.length() < 4 || password_temp.length() > 8){
            valid=false;
            passaword.setError("Between 4 and 9 alphanumeric characters");
        }else{
            passaword.setError(null);
        }

        return valid;
    }

    private void AcceptCredentials() {

        email=(EditText)findViewById(R.id.input_email);
        email_temp=email.getText().toString();



        passaword=(EditText)findViewById(R.id.input_password);
        password_temp=passaword.getText().toString();





        CheckPass=db_helper.searchPass(email_temp);

    }

    private void GoToSignup() {

        Link_signup=(TextView)findViewById(R.id.link_signup);
        Link_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent HomeIntent=new Intent(LogIn.this,SignUp.class);
                startActivity(HomeIntent);
            }
        });

    }

    private void CheckLoginStatus() {
        SharedPreferences pre=getSharedPreferences("Mydata",MODE_PRIVATE);
        if(pre.getBoolean("logstatus",true)){
            finishAffinity();
            Intent HomeIntent=new Intent(LogIn.this,MainActivity.class);
            startActivity(HomeIntent);
        }
    }


    private void validateLogIn() {


        bt_login=(Button) findViewById(R.id.btn_login);


        bt_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AcceptCredentials();
                Validate();
                if ((password_temp.equals("") || email_temp.equals(""))){

                    if(Validate())
                    Toast.makeText(getApplicationContext(),
                            "Please check credentials", Toast.LENGTH_SHORT).show();
                }else{

                    if (CheckPass.equals(password_temp)) {

                        SharedPreferences.Editor editor = getSharedPreferences("Mydata", MODE_PRIVATE).edit();
                        editor.putBoolean("logstatus", true);
                        editor.putString("myemail",email_temp);
                        editor.commit();

                        AlertDialog.Builder builder=new AlertDialog.Builder(LogIn.this);
                        View l_view=getLayoutInflater().inflate(R.layout.alert_dialog,null);
                        builder.setView(l_view);
                        final AlertDialog dialog=builder.create();
                        dialog.show();

                        new Handler().postDelayed(
                                new Runnable() {
                                    public void run() {
                                        dialog.dismiss();
                                        finishAffinity();
                                        Intent HomeIntent = new Intent(LogIn.this, MainActivity.class);
                                        startActivity(HomeIntent);
                                        finish();

                                    }
                                }, 2500);

                    } else {
                        if(Validate())
                        Toast.makeText(getApplicationContext(),
                                "Oops!...Password Incorrect or you haven't sign up yet", Toast.LENGTH_SHORT).show();
                    }


                }

            }
        });



    }



    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Fitness")
                .setMessage("Are you sure you want to exit?")
                .setNegativeButton(android.R.string.no, null)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface arg0, int arg1) {
                        LogIn.super.onBackPressed();

                    }
                }).create().show();
    }
}
