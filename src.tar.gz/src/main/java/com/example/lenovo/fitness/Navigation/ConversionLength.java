package com.example.lenovo.fitness.Navigation;

import android.icu.text.DecimalFormat;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lenovo.fitness.R;

/**
 * Created by lenovo on 8/9/17.
 */

public class ConversionLength extends AppCompatActivity {
    private static Toolbar t_bar;
    private static Spinner spinner_1,spinner_2;
    private static EditText Enter_value;
    private static TextView Set_Result;
    private double value,answer;
    private int flag1,flag2,flag3,flag4,flag5,flag6;
    private final double cm=1.0,inch=0.393701,feet=0.0328084;
    private static Button b1;
    java.text.DecimalFormat two = new java.text.DecimalFormat("#0.00");

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.conversionlength);
        DisplatToolBar();
        DisplaySpinner();
        calculateConversion();

    }

    public double cm_to_feet(){
        return answer=value*feet;
    }
    public double cm_to_inches(){
        return answer=value*inch;
    }
    public double feet_to_cm(){
        return answer=(value/feet);
    }
    public double feet_to_inch(){
        return answer=(value*inch)/feet;
    }
    public double inches_to_cm(){

        return answer=(value/inch);
    }
    public double inches_to_feet(){
        return answer=(value*feet)/inch;
    }

    private void AcceptQuantity() {

        try{
            value=Double.parseDouble(Enter_value.getText().toString());
            answer=value;

        }catch (NumberFormatException e){
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();

        }

    }


    private void calculateConversion() {

        Set_Result=(TextView)findViewById(R.id.SetResult);
        b1=(Button)findViewById(R.id.calculate);

        Enter_value=(EditText)findViewById(R.id.Quantity);




        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AcceptQuantity();
                DisplaySpinner();
                if(flag1==1&&flag5==1)cm_to_feet();
                if(flag1==1&&flag6==1)cm_to_inches();
                if(flag2==1&&flag4==1)feet_to_cm();
                if(flag2==1&&flag6==1)feet_to_inch();
                if(flag3==1&&flag4==1)inches_to_cm();
                if(flag3==1&&flag5==1)inches_to_feet();

                Set_Result.setText(two.format(answer));
            }
        });


    }

    private void DisplaySpinner() {
        spinner_1=(Spinner)findViewById(R.id.spinner1);
        spinner_2=(Spinner)findViewById(R.id.spinner2);

        ArrayAdapter arrayadapter=ArrayAdapter.createFromResource
                (this,R.array.units,android.R.layout.simple_spinner_dropdown_item);

        spinner_1.setAdapter(arrayadapter);
        spinner_2.setAdapter(arrayadapter);
        arrayadapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);



        //for choosing the convert from

        spinner_1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override

            public void onItemSelected(AdapterView<?> parent, View view, int choice, long id) {

                //use postion value
                switch (choice){

                    case 0:
                         flag1=1;
                        break;

                    case 1:
                         flag2=1;
                        break;

                    case 2:
                        flag3=1;
                        break;
                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        }); // on clicklistner of spinner1

        // for choosing convert to
        spinner_2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override

            public void onItemSelected(AdapterView<?> parent2, View view, int choice2, long id2) {




                //use postion value
                switch (choice2) {

                    case 0:

                        flag4=1;
                        break;

                    case 1:

                        flag5=1;

                        break;

                    case 2:
                        flag6=1;

                        break;
                }

            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        }); // on clicklistner of spinner2



    }
    private void DisplatToolBar(){

        t_bar=(Toolbar)findViewById(R.id.includec);
        setSupportActionBar(t_bar);

        if(getSupportActionBar()!=null){

            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle("Converter");
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
