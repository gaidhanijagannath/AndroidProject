package com.example.lenovo.fitness.Navigation;

import android.graphics.Typeface;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.lenovo.fitness.R;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by lenovo on 2/9/17.
 */

public class Supplementation extends Fragment {
    TextView t_view,t_view2,t_view3,t_view4,t_view5,t_view6,t_view7;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.supplementation,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Supplementation");
        CardDisplay();
    }

    public void CardDisplay(){

        t_view=getView().findViewById(R.id.card1_display_text);
        Typeface font= Typeface.createFromAsset(getActivity().getAssets(),"fonts/PAPL_.ttf");


        String DataRead="";
        StringBuffer sbuffer=new StringBuffer();
        InputStream is=this.getResources().openRawResource(R.raw.sup1);
        BufferedReader br=new BufferedReader(new InputStreamReader(is));

        if(is!=null){

            t_view.setTypeface(font);
            try{

                while((DataRead=br.readLine())!=null){
                    sbuffer.append(DataRead+"\n");
                }
                t_view.setText(sbuffer);
                is.close();

            }catch (Exception e){e.printStackTrace();}
        }


        t_view2=getView().findViewById(R.id.card1_display_text2);

        String DataRead2="";
        StringBuffer sbuffer2=new StringBuffer();
        InputStream is2=this.getResources().openRawResource(R.raw.sup2);
        BufferedReader br2=new BufferedReader(new InputStreamReader(is2));

        if(is2!=null){

            t_view2.setTypeface(font);
            try{

                while((DataRead2=br2.readLine())!=null){
                    sbuffer2.append(DataRead2+"\n");
                }
                t_view2.setText(sbuffer2);
                is2.close();

            }catch (Exception e){e.printStackTrace();}
        }




        t_view3=getView().findViewById(R.id.card1_display_text3);

        String DataRead3="";
        StringBuffer sbuffer3=new StringBuffer();
        InputStream is3=this.getResources().openRawResource(R.raw.sup3);
        BufferedReader br3=new BufferedReader(new InputStreamReader(is3));

        if(is3!=null){

            t_view3.setTypeface(font);

            try{

                while((DataRead3=br3.readLine())!=null){
                    sbuffer3.append(DataRead3+"\n");
                }
                t_view3.setText(sbuffer3);
                is3.close();

            }catch (Exception e){e.printStackTrace();}
        }

        t_view4=getView().findViewById(R.id.card1_display_text4);

        String DataRead4="";
        StringBuffer sbuffer4=new StringBuffer();
        InputStream is4=this.getResources().openRawResource(R.raw.sup4);
        BufferedReader br4=new BufferedReader(new InputStreamReader(is4));

        if(is4!=null){

            t_view4.setTypeface(font);

            try{

                while((DataRead4=br4.readLine())!=null){
                    sbuffer4.append(DataRead4+"\n");
                }
                t_view4.setText(sbuffer4);
                is4.close();

            }catch (Exception e){e.printStackTrace();}
        }



        t_view5=getView().findViewById(R.id.card1_display_text5);

        String DataRead5="";
        StringBuffer sbuffer5=new StringBuffer();
        InputStream is5=this.getResources().openRawResource(R.raw.sup5);
        BufferedReader br5=new BufferedReader(new InputStreamReader(is5));

        if(is5!=null){
            t_view5.setTypeface(font);

            try{

                while((DataRead5=br5.readLine())!=null){
                    sbuffer5.append(DataRead5+"\n");
                }
                t_view5.setText(sbuffer5);
                is5.close();

            }catch (Exception e){e.printStackTrace();}
        }
    }//function end
}
