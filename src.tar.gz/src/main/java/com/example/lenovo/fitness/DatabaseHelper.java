package com.example.lenovo.fitness;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.lenovo.fitness.LogIn;

/**
 * Created by lenovo on 18/9/17.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION=1;
    private static final String column_ID ="id";
    private static final String DATABASE_NAME="UserInfo1.db";
    private static final String TABLE_NAME="Details";
    private static final String column_name="name";
    private static final String column_email="email";
    private static final String column_pass="pass";
    SQLiteDatabase sqLiteDatabase;


    private static final String query="CREATE table Details (id integer primary key not null,"+
            "name text not null,"+"email text not null,pass text not null)";



    public DatabaseHelper(Context context) {
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL(query);
        this.sqLiteDatabase=sqLiteDatabase;
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int old_version, int new_version) {
        String drop="DROP TABLE IF EXISTS "+TABLE_NAME;
        sqLiteDatabase.execSQL(drop);
        this.onCreate(sqLiteDatabase);

    }
    public void InsertContact(ContactInfo c_info){

        sqLiteDatabase=this.getWritableDatabase();
        ContentValues values=new ContentValues();

        String Query="Select * from Details";
        Cursor cursor=sqLiteDatabase.rawQuery(Query,null);
        int count=cursor.getCount();

        values.put(column_ID,count);
        values.put(column_name,c_info.getName());
        values.put(column_email,c_info.getEmail());
        values.put(column_pass,c_info.getPassword());

        sqLiteDatabase.insert(TABLE_NAME,null,values);

        sqLiteDatabase.close();
    }


    public String searchPass(String email_temp) {
        sqLiteDatabase=this.getReadableDatabase();
        String SearchQuery="select email,pass from "+TABLE_NAME;
        Cursor cursor=sqLiteDatabase.rawQuery(SearchQuery,null);

        String Result="No Result Found!...";
        String _name="";
        if(cursor.moveToFirst()){

            do{
                _name=cursor.getString(0);
                if(email_temp.equals(_name)){
                    Result=cursor.getString(1);
                }

            }while (cursor.moveToNext());

        }



        sqLiteDatabase.close();
        return Result;
    }

    public boolean checkID(String email) {
        boolean Status=false;
        sqLiteDatabase=this.getReadableDatabase();
        String SearchEmail="select email from "+TABLE_NAME;
        Cursor cursor=sqLiteDatabase.rawQuery(SearchEmail,null);
        String name="";
        if(cursor.moveToFirst()){

            do{
                name=cursor.getString(0);
                if(name.equals(email)){
                    Status=true;
                }

            }while(cursor.moveToNext());
        }

        sqLiteDatabase.close();
        return Status;
    }
}
