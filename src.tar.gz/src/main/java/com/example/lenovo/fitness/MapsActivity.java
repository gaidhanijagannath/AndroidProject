package com.example.lenovo.fitness;


import android.Manifest;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.support.v7.widget.SearchView; // not the default !

import com.google.android.gms.actions.SearchIntents;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApi;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.List;

import at.markushi.ui.CircleButton;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback,
        GoogleApiClient.OnConnectionFailedListener,
        GoogleApiClient.ConnectionCallbacks,
        com.google.android.gms.location.LocationListener {

    private int PROXIMITY_RADIUS =5000;
    private Toolbar t_bar;

    SearchView searchView;
    private CircleButton search;
    private Button Search_Gym;
    private EditText E_location;
    private GoogleMap mMap;
    private GoogleApiClient apiclient;
    private LocationRequest locationRequest;
    private Location _location;
    private Marker CurrentLocationMarker;
    private static final int REQUEST_CODE=333;
    private String[] permission={Manifest.permission.ACCESS_FINE_LOCATION};
    String location;
    double latitude,longitude;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        ShowToolBar();

        //verifying build version

        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M){
            CheckLocationPermission();
        }

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);



        Search_Gym=(Button)findViewById(R.id.search_gym);
        Search_Gym.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Object dataTransfer[] = new Object[2];
                GetNearByPlacesData getNearbyplacesdata=new GetNearByPlacesData();
                //if there is any previous marker clear it out
                mMap.clear();
                String NearByPlace ="gym";
                String url = getUrl(latitude, longitude,NearByPlace);

                //passing the parameter of string and GoogleMap
                dataTransfer[0] = mMap;
                dataTransfer[1] = url;
                //call Async Class in the GetNearByPlacesMethod
                getNearbyplacesdata.execute(dataTransfer);
                Toast.makeText(MapsActivity.this, "Showing Nearby Gyms", Toast.LENGTH_SHORT).show();

            }
        });
    }

    private String getUrl(double latitude,double longitude,String NearByPlace){


        StringBuilder googlePlaceUrl = new StringBuilder("https://maps.googleapis.com/maps/api/place/nearbysearch/json?");
        googlePlaceUrl.append("location="+latitude+","+longitude);
        googlePlaceUrl.append("&radius="+PROXIMITY_RADIUS);
        googlePlaceUrl.append("&type="+NearByPlace);
        googlePlaceUrl.append("&sensor=true");
        googlePlaceUrl.append("&key="+"AIzaSyC67dQr0JA2VgrkmFEMMKIx-LzEuCH1W_Y");

        Log.d("MapsActivity", "url = "+googlePlaceUrl.toString());

        return googlePlaceUrl.toString();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        getMenuInflater().inflate(R.menu.searchview,menu);

        final MenuItem searchItem = menu.findItem(R.id.search);

        searchView = (SearchView) searchItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String location) {
                // Toast like print
                if( ! searchView.isIconified()) {
                    searchView.setIconified(true);
                }
                MarkerOptions mo=new MarkerOptions();

                List<Address> AddressList = null;

                if(!location.equals("")){

                    Geocoder geocoder=new Geocoder(MapsActivity.this);

                    try {

                        AddressList=geocoder.getFromLocationName(location,5);

                    } catch (IOException e) {

                        e.printStackTrace();
                    }

                    for (int i = 0; i <AddressList.size() ; i++) {

                        Address myaddress=AddressList.get(i);
                        LatLng latlng=new LatLng(myaddress.getLatitude(),myaddress.getLongitude());
                        mo.position(latlng);
                        mo.title("Your search results");

                        mMap.clear();
                        mMap.addMarker(mo);
                        mMap.animateCamera(CameraUpdateFactory.newLatLng(latlng));
                    }
                    searchItem.collapseActionView();
                }

                return false;
            }
            @Override
            public boolean onQueryTextChange(String s) {

                return false;
            }
        });
        return true;
    }



    private void ShowToolBar(){
        t_bar=(Toolbar)findViewById(R.id.includemaps);
        setSupportActionBar(t_bar);

        if(getSupportActionBar()!=null){

            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle("Search for places");
        }



    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }



    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)== PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.

            BuildGoogleApiClient();
            mMap.setMyLocationEnabled(true);
        }

    }

    protected synchronized void BuildGoogleApiClient(){
        apiclient=new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        apiclient.connect();

    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

        locationRequest=new LocationRequest();
        locationRequest.setInterval(1000);
        locationRequest.setFastestInterval(1000);



         /*
          * when applications definitely want to receive updates at a specified interval,
          * and can receive them faster when available, but still want a low power impact.
          * These applications should consider PRIORITY_BALANCED_POWER_ACCURACY
          *
          *
          */

        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);

        // checking permission for connection


        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)
                ==PackageManager.PERMISSION_GRANTED);
        {
            LocationServices.FusedLocationApi.requestLocationUpdates(apiclient,locationRequest,this);
        }



    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {



        latitude=location.getLatitude();
        longitude=location.getLongitude();

        _location=location;

        if(CurrentLocationMarker!=null){
            CurrentLocationMarker.remove();
        }

        LatLng latLng=new LatLng(location.getLatitude(),location.getLongitude());

        MarkerOptions markerOptions=new MarkerOptions()
                .position(latLng)
                .title("Here you are")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));


        CurrentLocationMarker=mMap.addMarker(markerOptions);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));

        CameraPosition cameraPosition = new CameraPosition(new LatLng(
                location.getLatitude(), location.getLongitude()),
                mMap.getCameraPosition().zoom, 45, 360);
                mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));



        if(apiclient!=null){

            LocationServices.FusedLocationApi.removeLocationUpdates(apiclient,this);
        }
    }

    protected boolean CheckLocationPermission(){


        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)
                !=PackageManager.PERMISSION_GRANTED){

            // This permission is for if user had already neen asked for permission and he denied that
            if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.ACCESS_FINE_LOCATION)){

                ActivityCompat.requestPermissions(this,permission,REQUEST_CODE);
            }else{
                ActivityCompat.requestPermissions(this,permission,REQUEST_CODE);

            }

            return false;

        }else
            return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){

            case REQUEST_CODE:
                if(grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){

                    // permission  has granted

                    if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)
                            ==PackageManager.PERMISSION_GRANTED)
                    {
                        if(apiclient==null){

                            BuildGoogleApiClient();
                        }

                        mMap.setMyLocationEnabled(true);
                    }
                }else{

                    Toast.makeText(getApplicationContext(),"Permission denied", Toast.LENGTH_SHORT).show();
                }
        }
    }


}
