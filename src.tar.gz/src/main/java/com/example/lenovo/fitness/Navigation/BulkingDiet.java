package com.example.lenovo.fitness.Navigation;

import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.lenovo.fitness.R;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * Created by lenovo on 2/9/17.
 */

public class BulkingDiet extends Fragment {
    TextView t_view,t_view2,t_view3,t_view4,t_view5,t_view6;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bulkingdiet,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Bulking Diet");
        CardDisplay();
    }
    private void CardDisplay(){
        t_view=getView().findViewById(R.id.card1_display_text);

        Typeface custom_font=Typeface.createFromAsset(getActivity().getAssets(),
                "fonts/PAPL_.ttf");
        t_view.setTypeface(custom_font);

        String DataRead="";
        StringBuffer sbuffer=new StringBuffer();
        InputStream is=this.getResources().openRawResource(R.raw.bulk1);
        BufferedReader br=new BufferedReader(new InputStreamReader(is));

        if(is!=null){

            try{

                while((DataRead=br.readLine())!=null){
                    sbuffer.append(DataRead+"\n");
                }
                t_view.setText(sbuffer);
                is.close();

            }catch (Exception e){e.printStackTrace();}
        }


        t_view2=getView().findViewById(R.id.card1_display_text2);

        String DataRead2="";
        StringBuffer sbuffer2=new StringBuffer();
        InputStream is2=this.getResources().openRawResource(R.raw.bulk2);
        BufferedReader br2=new BufferedReader(new InputStreamReader(is2));

        if(is2!=null){

            try{

                t_view2.setTypeface(custom_font);
                while((DataRead2=br2.readLine())!=null){
                    sbuffer2.append(DataRead2+"\n");
                }
                t_view2.setText(sbuffer2);
                is2.close();

            }catch (Exception e){e.printStackTrace();}
        }




        t_view3=getView().findViewById(R.id.card1_display_text3);

        String DataRead3="";
        StringBuffer sbuffer3=new StringBuffer();
        InputStream is3=this.getResources().openRawResource(R.raw.bulk3);
        BufferedReader br3=new BufferedReader(new InputStreamReader(is3));

        if(is3!=null){

            try{

                t_view3.setTypeface(custom_font);
                while((DataRead3=br3.readLine())!=null){
                    sbuffer3.append(DataRead3+"\n");
                }
                t_view3.setText(sbuffer3);
                is3.close();

            }catch (Exception e){e.printStackTrace();}
        }

        t_view4=getView().findViewById(R.id.card1_display_text4);

        String DataRead4="";
        StringBuffer sbuffer4=new StringBuffer();
        InputStream is4=this.getResources().openRawResource(R.raw.bulk4);
        BufferedReader br4=new BufferedReader(new InputStreamReader(is4));

        if(is4!=null){

            try{

                t_view4.setTypeface(custom_font);
                while((DataRead4=br4.readLine())!=null){
                    sbuffer4.append(DataRead4+"\n");
                }
                t_view4.setText(sbuffer4);
                is4.close();

            }catch (Exception e){e.printStackTrace();}
        }



        t_view5=getView().findViewById(R.id.card1_display_text5);

        String DataRead5="";
        StringBuffer sbuffer5=new StringBuffer();
        InputStream is5=this.getResources().openRawResource(R.raw.bulk5);
        BufferedReader br5=new BufferedReader(new InputStreamReader(is5));

        if(is5!=null){

            try{

                t_view5.setTypeface(custom_font);
                while((DataRead5=br5.readLine())!=null){
                    sbuffer5.append(DataRead5+"\n");
                }
                t_view5.setText(sbuffer5);
                is5.close();

            }catch (Exception e){e.printStackTrace();}
        }


        t_view6=getView().findViewById(R.id.card1_display_text6);

        String DataRead6="";
        StringBuffer sbuffer6=new StringBuffer();
        InputStream is6=this.getResources().openRawResource(R.raw.bulk6);
        BufferedReader br6=new BufferedReader(new InputStreamReader(is6));

        if(is6!=null){

            try{

                t_view6.setTypeface(custom_font);
                while((DataRead6=br6.readLine())!=null){
                    sbuffer6.append(DataRead6+"\n");
                }
                t_view6.setText(sbuffer6);
                is6.close();

            }catch (Exception e){e.printStackTrace();}
        }

    }//function end


}
