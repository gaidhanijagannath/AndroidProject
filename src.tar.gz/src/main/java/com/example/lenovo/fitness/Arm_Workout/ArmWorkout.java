package com.example.lenovo.fitness.Arm_Workout;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.lenovo.fitness.CalendarDatabase;
import com.example.lenovo.fitness.MainActivity;
import com.example.lenovo.fitness.R;

import java.util.ArrayList;

public class ArmWorkout extends AppCompatActivity {
    Toolbar t_bar;
    ListView L_view;
    Button Start;
    MediaPlayer mp;
    CalendarDatabase c_data=new CalendarDatabase(ArmWorkout.this);
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arm_workout);
        ShowToolBar();
        ShowList();
        ButtonClick();
        mp=MediaPlayer.create(this,R.raw.whistle);

    }

    private void ButtonClick() {

        Start=(Button)findViewById(R.id.start);

        Start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mp.start();

                new android.os.Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mp.stop();
                        Intent intent=new Intent(ArmWorkout.this,push_ups.class);
                        startActivity(intent);
                    }
                },1000);

            }
        });


    }

    private void ShowList() {

        L_view=(ListView)findViewById(R.id.arm_list_view);

        L_view.setAdapter(new List_view_Adapter(this));

        L_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                if(position==0){
                    Intent intent=new Intent(ArmWorkout.this,push_ups.class);
                    startActivity(intent);
                }
                if(position==1){
                    Intent intent=new Intent(ArmWorkout.this,triceps_dips.class);
                    startActivity(intent);
                }
                if(position==2){
                    Intent intent=new Intent(ArmWorkout.this,Mountain_climbers.class);
                    startActivity(intent);
                }
                if(position==3){
                    Intent intent=new Intent(ArmWorkout.this,Arm_circles.class);
                    startActivity(intent);
                }
                if(position==4){
                    Intent intent=new Intent(ArmWorkout.this,plank.class);
                    startActivity(intent);
                }
            }
        });
    }

    private void ShowToolBar(){
        t_bar=(Toolbar)findViewById(R.id.includearm);
        setSupportActionBar(t_bar);

        if(getSupportActionBar()!=null){

            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle("Arm Workout");
        }



    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}


class CompositeObject{
    String exercise_name,Reps;
    int images;

    CompositeObject(String exercise_name,String Reps,int images){
        this.exercise_name=exercise_name;
        this.Reps=Reps;
        this.images=images;
    }

}
class List_view_Adapter extends BaseAdapter{

    ArrayList<CompositeObject> List;

    Context context;
    List_view_Adapter(Context c){

        context=c;
        List=new ArrayList<CompositeObject>();
        Resources res=c.getResources();
        String Arm_exercises[]=res.getStringArray(R.array.ArmExercises);
        String Reps[]=res.getStringArray(R.array.MaxReps);
        int images[]={R.drawable.dumbbell,R.drawable.dumbbell,R.drawable.dumbbell,
                R.drawable.dumbbell,R.drawable.dumbbell};

        for (int i=0;i<5;i++){

            List.add(new CompositeObject(Arm_exercises[i],Reps[i],images[i]));
        }
    }

    @Override
    public int getCount() {
        return List.size();
    }

    @Override
    public Object getItem(int i) {
        return List.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row=inflater.inflate(R.layout.single_row_layout,viewGroup,false);

        TextView exercise=row.findViewById(R.id.Exs);
        TextView reps=row.findViewById(R.id.Reps);
        ImageView image=row.findViewById(R.id.image_View);

        CompositeObject comp=List.get(i);

         exercise.setText(comp.exercise_name);
         reps.setText(comp.Reps);
        image.setImageResource(comp.images);

        return row;
    }
}

