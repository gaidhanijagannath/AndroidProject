package com.example.lenovo.fitness.Navigation;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lenovo.fitness.R;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by lenovo on 2/9/17.
 */

public class CalculateMR extends Fragment {

    TextView t_view, ans;
    private double Repitations;
    private double Weight_kg;
    private static EditText Reps, weight;
    private int MR;
    int flag = 0;
    String Reps_temp,weight_temp;
    DecimalFormat two = new DecimalFormat("#0.00");

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.calculatemr, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Caluculate 1 MR");
        CardDisplay();
        CalculateMR();
    }

    private void CardDisplay() {

        t_view = getView().findViewById(R.id.mrtext);

        String DataRead = "";
        StringBuffer sbuffer = new StringBuffer();
        InputStream is = this.getResources().openRawResource(R.raw.mr);
        BufferedReader br = new BufferedReader(new InputStreamReader(is));

        if (is != null) {

            try {

                while ((DataRead = br.readLine()) != null) {
                    sbuffer.append(DataRead + "\n");
                }
                t_view.setText(sbuffer);
                is.close();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void AcceptData() {

        Reps = getView().findViewById(R.id.enterreps);
        Reps_temp=Reps.getText().toString();

        weight = getView().findViewById(R.id.enterweight);
        weight_temp=weight.getText().toString();


    }
    private void ConvertValues(){

        Repitations = Double.parseDouble(Reps_temp);

        Weight_kg = Double.parseDouble(weight_temp);


        if (flag == 2) {
            Weight_kg = Weight_kg * 0.45359237;
        }
    }

    private boolean Validate(){
        boolean valid=true;

        if(Reps_temp.equals("")){
            valid=false;
            Reps.setError("Field shouldn't be empty");
        }
        if(weight_temp.equals("")){
            valid=false;
            weight.setError("Field shouldn't be empty");
        }
        return valid;
    }
    private void radiogroup1() {

        RadioGroup radioGroup1 = getView().findViewById(R.id.Radiogroupmr1);
        radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int checkID) {


                switch (checkID) {

                    case R.id.kg_cm:
                        flag = 1;
                        break;

                    case R.id.ft_lbs:
                        flag = 2;
                        break;
                }
            }
        });

    }


    private void CalculateMR() {


        Button button = getView().findViewById(R.id.calculatemr);

        button.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                radiogroup1();
                AcceptData();


                if(!Validate()){


                }else {
                        ConvertValues();

                        if (Repitations == 0.0 || Weight_kg == 0.0) {

                            Toast.makeText(getActivity(), "Check the values", Toast.LENGTH_SHORT).show();
                        } else {
                            MR = (int) (Weight_kg * (1 + (Repitations / 30)));

                            SharedPreferences preferences=getActivity().getSharedPreferences("Mydata",MODE_PRIVATE);
                            SharedPreferences.Editor editor=preferences.edit();
                            editor.putString("mr",two.format(MR));
                            editor.commit();

                            ans = getView().findViewById(R.id.answer);


                            ans.setText(two.format(MR));
                        }


                }


            }
        });

    }
}
