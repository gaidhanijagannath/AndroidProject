package com.example.lenovo.fitness;

import android.content.Intent;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.example.lenovo.fitness.Arm_Workout.ArmWorkout;
import com.example.lenovo.fitness.Body_Workout.BodyWorkout;
import com.example.lenovo.fitness.Butt_Workout.ButtWorkout;
import com.example.lenovo.fitness.Leg_Workout.LegWorkout;
import com.example.lenovo.fitness.Navigation.Aboutus;
import com.example.lenovo.fitness.Navigation.BulkingDiet;
import com.example.lenovo.fitness.Navigation.CalculateBmi;
import com.example.lenovo.fitness.Navigation.CalculateFat;
import com.example.lenovo.fitness.Navigation.CalculateMR;
import com.example.lenovo.fitness.Navigation.Calendar_;
import com.example.lenovo.fitness.Navigation.Calorie;
import com.example.lenovo.fitness.Navigation.CuttingDiet;
import com.example.lenovo.fitness.Navigation.Exercises;
import com.example.lenovo.fitness.Navigation.SuggestDiet;
import com.example.lenovo.fitness.Navigation.Supplementation;
import com.example.lenovo.fitness.Navigation.Tip;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private CardView i_arm,i_leg,i_butt,i_body;
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle m_toggle;
    private Toolbar t_bar;
    Fragment fragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar();
        NevigationBar();
        OnDrawerLayout();
        OnCardClick();
    }

    private void ActionBar(){
        t_bar=(Toolbar)findViewById(R.id.include2);
        setSupportActionBar(t_bar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }
    private void NevigationBar() {


        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    private void OnDrawerLayout() {

        drawerLayout=(DrawerLayout)findViewById(R.id.Drawer_layout);
        m_toggle=new ActionBarDrawerToggle(this,drawerLayout,R.string.Open,R.string.Close);

        drawerLayout.addDrawerListener(m_toggle);
        m_toggle.syncState();


    }

    /*
    * Below method is used to enabled the menu icon on selection
    * */


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //to explore the toggle button
        if(m_toggle.onOptionsItemSelected(item))return true;
        //noinspection SimplifiableIfStatement

        if (id == R.id.action_settings) {
            Intent intent=new Intent(MainActivity.this,Settings.class);
            startActivity(intent);
            return true;
        }
        if (id == R.id.action_about_us) {
            Intent intent=new Intent(MainActivity.this,Aboutus.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_Exercises) {
           fragment=new Exercises();
            FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame_layout,fragment).commit();

        } else if (id == R.id.nav_calendar) {
            fragment=new Calendar_();
            FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame_layout,fragment).commit();

        } else if (id == R.id.nav_kCalsneeded) {
            fragment=new Calorie();
            FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame_layout,fragment).commit();

        } else if (id == R.id.nav_Ex_BulkingDiet) {
            fragment=new BulkingDiet();
            FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame_layout,fragment).commit();

        } else if (id == R.id.nav_Ex_CuttingDiet) {
            fragment=new CuttingDiet();
            FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame_layout,fragment).commit();

        } else if (id == R.id.nav_Supplementation) {
            fragment=new Supplementation();
            FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame_layout,fragment).commit();

        }else if(id==R.id.nav_Tips){
            fragment=new Tip();
            FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame_layout,fragment).commit();


        }else if (id == R.id.nav_CalculateBMI){
            fragment=new CalculateBmi();
            FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame_layout,fragment).commit();
        }
        else if(id==R.id.nav_CalculateFat){

            fragment=new CalculateFat();
            FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame_layout,fragment).commit();
        }

        else if(id==R.id.nav_Calculate1MR){

            fragment=new CalculateMR();
            FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame_layout,fragment).commit();
        }
        else if(id==R.id.nav_search_nearby){

            Intent MapIntent=new Intent(getApplicationContext(),MapsActivity.class);
            startActivity(MapIntent);

        }else if(id==R.id.nav_suggest_diet){

            fragment=new SuggestDiet();
            FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.frame_layout,fragment).commit();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.Drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;

    }

  public void OnCardClick(){

        i_arm=(CardView)findViewById(R.id.cardviewarm);
        i_leg=(CardView)findViewById(R.id.cardviewleg);
        i_body=(CardView)findViewById(R.id.cardViewfull);
        i_butt=(CardView)findViewById(R.id.cardviewbutt);


        i_arm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,ArmWorkout.class);
                startActivity(intent);

            }
        });
        i_leg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1=new Intent(MainActivity.this,LegWorkout.class);
                startActivity(intent1);

            }
        });
        i_butt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2=new Intent(MainActivity.this,ButtWorkout.class);
                startActivity(intent2);

            }
        });
        i_body.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent3=new Intent(MainActivity.this,BodyWorkout.class);
                startActivity(intent3);

            }
        });

    }


    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }
}
