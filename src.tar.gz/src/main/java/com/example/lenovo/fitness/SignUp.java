package com.example.lenovo.fitness;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class SignUp extends AppCompatActivity {

    private Button bt_signup;
    private TextView link_login_;
    private EditText i_name,i_email,i_pass,i_cpass;
    private String name,email,pass,c_pass;


    //Database helper class to insert database from here
    DatabaseHelper db_helper=new DatabaseHelper(SignUp.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        ValidateSignUp();
        GoToLogIn();


    }

    private void GoToLogIn() {


        //move to log in if you are already member
        link_login_=(TextView)findViewById(R.id.link_login);
        link_login_.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent HomeIntent=new Intent(SignUp.this,LogIn.class);
                startActivity(HomeIntent);

            }
        });

    }

    private void SubmitData() {

        ContactInfo c_info=new ContactInfo();
        c_info.setName(name);
        c_info.setEmail(email);
        c_info.setPassword(pass);

        db_helper.InsertContact(c_info);
    }

    private void ValidateSignUp() {


        bt_signup=(Button) findViewById(R.id.btn_signup);

        bt_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AcceptData();
                if(c_pass.equals(pass) && Validate()){
                    //insert data in database
                    SubmitData();
                    Toast.makeText(getApplicationContext(),"Signed up successfully!!",Toast.LENGTH_SHORT).show();
                }else{
                    if(Validate())
                    Toast.makeText(getApplicationContext(),"Oops!..Password doesn't match!",Toast.LENGTH_SHORT).show();
                }





            }
        });

    }
    private void AcceptData() {

      i_name=(EditText)findViewById(R.id.input_name);
      i_email=(EditText)findViewById(R.id.input_email);
      i_pass=(EditText)findViewById(R.id.input_password);
      i_cpass=(EditText)findViewById(R.id.input_conform_password);

      name=i_name.getText().toString();
      email=i_email.getText().toString();
      pass=i_pass.getText().toString();
      c_pass=i_cpass.getText().toString();




    }

    public boolean Validate(){

        boolean Valid=true;

            if(name.length()<3){
                Valid=false;
                i_name.setError("at least 3 characters");

            }else{
                i_name.setError(null);
            }



            if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                i_email.setError("Enter a valid email address");
                Valid=false;
            }else{
                i_email.setError(null);
            }



            if(pass.length() < 4 || pass.length() > 8){
                Valid=false;
                i_pass.setError("Between 4 and 9 alphanumeric characters");
            }else{

                i_pass.setError(null);
            }


            if(c_pass.length() < 4 || c_pass.length() > 8){
                Valid=false;
            i_cpass.setError("Between 4 and 9 alphanumeric characters");
            }else{
                i_cpass.setError(null);}



        return Valid;
    }


}
