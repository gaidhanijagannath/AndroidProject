package com.example.lenovo.fitness;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

import at.markushi.ui.CircleButton;

public class Settings extends AppCompatActivity {

    Toolbar t_bar;
    Switch switch_notification;
    CircleButton LogOut;
    TextView t_logout;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);
        switch_notification=(Switch)findViewById(R.id.switch1);
        ShowToolBar();
        CheckSwitch();
        NotificationDisplay();
        Logout();
        SetLog();
    }

    private void SetLog(){
        t_logout=(TextView)findViewById(R.id.textview_logout);
        SharedPreferences shared=getSharedPreferences("Mydata",MODE_PRIVATE);
        String str=shared.getString("myemail","");
        t_logout.setText(str);

    }



    /*getting value from preferences*/

    private void CheckSwitch() {
        SharedPreferences sharedpreferences=getSharedPreferences("Mydata",MODE_PRIVATE);

        if(sharedpreferences.getBoolean("notification_enable",true)){
            Toast.makeText(getApplicationContext(), "notification enable", Toast.LENGTH_SHORT).show();
            switch_notification.setChecked(true);
            StartNotification();
        }else{
            Toast.makeText(getApplicationContext(), "notification disable", Toast.LENGTH_SHORT).show();
            switch_notification.setChecked(false);

        }

    }



    private void NotificationDisplay() {

        switch_notification.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean check) {

                SharedPreferences.Editor Editor=getSharedPreferences("Mydata",MODE_PRIVATE).edit();

                if(check){
                    /* putting value in preferences*/
                    Editor.putBoolean("notification_enable",true);
                }
                else{

                    Editor.putBoolean("notification_enable",false);
                }
                Editor.commit();


            }
        });


    }

    private void StartNotification() {

        Calendar calendar=Calendar.getInstance();

        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(calendar.HOUR_OF_DAY,7);
        calendar.set(calendar.MINUTE,30);
        calendar.set(calendar.SECOND,0);


        Intent intent=new Intent(getApplicationContext(),NotificationReciever.class);
        PendingIntent pendingIntent=PendingIntent.getBroadcast(getApplicationContext(),007,intent,PendingIntent.FLAG_UPDATE_CURRENT);

        AlarmManager alarmManager=(AlarmManager)getSystemService(ALARM_SERVICE);

        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,calendar.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pendingIntent);

    }


    private void Logout() {

        LogOut=(CircleButton)findViewById(R.id.button_logout_settings);
        LogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor=getSharedPreferences("Mydata",MODE_PRIVATE).edit();
                editor.putBoolean("logstatus",false);
                editor.putString("myemail","");

                editor.putString("bmi","0.00");
                editor.putString("fat","0.00");
                editor.putString("mr","0.00");
                editor.putString("calorie","0.00");
                editor.commit();
                
                finishAffinity();
                Intent LoginIntent=new Intent(Settings.this, LogIn.class);
                startActivity(LoginIntent);
            }
        });

    }



    private void ShowToolBar() {

        t_bar=(Toolbar)findViewById(R.id.setting_id);
        setSupportActionBar(t_bar);

        if(getSupportActionBar()!=null){

            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle("Settings");
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }




}
