package com.example.lenovo.fitness.Butt_Workout;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.lenovo.fitness.Body_Workout.Step_ups;
import com.example.lenovo.fitness.Leg_Workout.LegWorkout;
import com.example.lenovo.fitness.Leg_Workout.Leg_lifts;
import com.example.lenovo.fitness.Leg_Workout.Lunges;
import com.example.lenovo.fitness.Leg_Workout.Wall_sit;
import com.example.lenovo.fitness.R;

import java.util.ArrayList;

public class ButtWorkout extends AppCompatActivity {
    Toolbar t_bar;
    ListView list;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_butt_workout);
        ShowToolBar();
        ShowList();
    }
    private void ShowList() {

        list=(ListView)findViewById(R.id.butt_list_view);
        list.setAdapter(new List_view_Adapter2(this));


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                if(position==0){
                    Intent intent=new Intent(ButtWorkout.this,Squats.class);
                    startActivity(intent);
                }
                if(position==1){
                    Intent intent=new Intent(ButtWorkout.this,Rainbow_plank.class);
                    startActivity(intent);
                }
                if(position==2){
                    Intent intent=new Intent(ButtWorkout.this,Butterfly_hip_rises.class);
                    startActivity(intent);
                }
                if(position==3){
                    Intent intent=new Intent(ButtWorkout.this,Step_ups.class);
                    startActivity(intent);
                }
                if(position==4){
                    Intent intent=new Intent(ButtWorkout.this,Donkey_kicks.class);
                    startActivity(intent);
                }
            }
        });

    }
    private void ShowToolBar() {

        t_bar=(Toolbar)findViewById(R.id.includebutt);
        setSupportActionBar(t_bar);

        if(getSupportActionBar()!=null){

            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle("Butt Workout");
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
class CompositeObject2{
    String exercise_name,Reps;
    int images;

    CompositeObject2(String exercise_name,String Reps,int images){
        this.exercise_name=exercise_name;
        this.Reps=Reps;
        this.images=images;
    }

}
class List_view_Adapter2 extends BaseAdapter {

    ArrayList<CompositeObject2> List;

    Context context;
    List_view_Adapter2(Context c){

        context=c;
        List=new ArrayList<CompositeObject2>();
        Resources res=c.getResources();
        String Arm_exercises[]=res.getStringArray(R.array.ButtExercises);
        String Reps[]=res.getStringArray(R.array.MaxReps2);
        int images[]={R.drawable.dumbbell,R.drawable.dumbbell,R.drawable.dumbbell,
                R.drawable.dumbbell,R.drawable.dumbbell};

        for (int i=0;i<5;i++){

            List.add(new CompositeObject2(Arm_exercises[i],Reps[i],images[i]));
        }
    }

    @Override
    public int getCount() {
        return List.size();
    }

    @Override
    public Object getItem(int i) {
        return List.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row=inflater.inflate(R.layout.single_row_layout,viewGroup,false);

        TextView exercise=row.findViewById(R.id.Exs);
        TextView reps=row.findViewById(R.id.Reps);
        ImageView image=row.findViewById(R.id.image_View);

        CompositeObject2 comp=List.get(i);

        exercise.setText(comp.exercise_name);
        reps.setText(comp.Reps);
        image.setImageResource(comp.images);

        return row;
    }
}
