package com.example.lenovo.fitness;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.TaskStackBuilder;
import android.support.v7.app.NotificationCompat;

/**
 * Created by lenovo on 13/9/17.
 */

public class NotificationReciver extends BroadcastReceiver {
    private static final int unique_id=12345;
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent notificationIntent=new Intent(context, MainActivity.class);

        TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
        stackBuilder.addParentStack(MainActivity.class);
        stackBuilder.addNextIntent(notificationIntent);

        PendingIntent pendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context);

        Notification notification = builder.setContentTitle("Fitness")
                .setContentText("Don't forget to exercise")
                .setTicker("notification from fitness")
                .setSmallIcon(R.drawable.runner)
                .setContentIntent(pendingIntent).build();

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(unique_id, notification);

    }
}
