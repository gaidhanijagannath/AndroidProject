package com.example.lenovo.fitness.Body_Workout;

import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.lenovo.fitness.R;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Step_ups extends AppCompatActivity {

    Toolbar t_bar;
    TextView t_view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_step_ups);
        ShowToolBar();
        CardDisplay();
    }
    private void CardDisplay() {
        t_view=(TextView) findViewById(R.id.step_ups_txtview);

        Typeface custom_font=Typeface.createFromAsset(getApplicationContext().getAssets(),
                "fonts/PAPL_.ttf");
        t_view.setTypeface(custom_font);

        String DataRead="";
        StringBuffer sbuffer=new StringBuffer();
        InputStream is=this.getResources().openRawResource(R.raw.stepups);
        BufferedReader br=new BufferedReader(new InputStreamReader(is));

        if(is!=null){

            try{

                while((DataRead=br.readLine())!=null){
                    sbuffer.append(DataRead+"\n");
                }
                t_view.setText(sbuffer);
                is.close();

            }catch (Exception e){e.printStackTrace();}
        }

    }


    private void ShowToolBar(){
        t_bar=(Toolbar)findViewById(R.id.include_step_ups);
        setSupportActionBar(t_bar);

        if(getSupportActionBar()!=null){

            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle("Steps_ups");
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
