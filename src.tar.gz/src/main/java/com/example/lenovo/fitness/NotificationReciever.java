package com.example.lenovo.fitness;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.NotificationCompat;

import com.example.lenovo.fitness.MainActivity;
import com.example.lenovo.fitness.R;

/**
 * Created by lenovo on 12/9/17.
 */

public class NotificationReciever extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {

        NotificationManager notificationManager=(NotificationManager)context.getSystemService(Context
                .NOTIFICATION_SERVICE);

        Intent intent1=new Intent(context,MainActivity.class);
        intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent=PendingIntent.getActivity(context,007,intent1,PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder= (NotificationCompat.Builder) new NotificationCompat.Builder(context)
                .setContentIntent(pendingIntent)
                .setTicker("Notification from Fitness")
                .setWhen(System.currentTimeMillis())
                .setContentTitle("Fitness")
                .setContentText("Don't forgot to excercise").setAutoCancel(true)
                .setSmallIcon(R.drawable.runner)
                .setAutoCancel(true);


        notificationManager.notify(007,builder.build());
    }
}
