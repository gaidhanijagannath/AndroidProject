package com.example.lenovo.fitness.Navigation;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lenovo.fitness.R;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;

/**
 * Created by lenovo on 2/9/17.
 */

public class CalculateFat extends Fragment {
    TextView t_view,ans;
    private static Button b1,b2;
    private double Height_cm,Weight_kg,Waist,Hip,Neck;
    private EditText height,weight,waist,hip,neck;
    private double fat;
    int flag=0;
    String category="";
    DecimalFormat two = new DecimalFormat("#0.00");
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.calculatefat,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Calculate fat");
        CardDisplay();
        convert();
        CalculateFAT();

    }

    private void convert() {

        b1=getView().findViewById(R.id.convertfat1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(),ConversionLength.class);
                getActivity().startActivity(intent);
            }
        });

        b2=getView().findViewById(R.id.convertfat2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(),ConversionWeight.class);
                getActivity().startActivity(intent);
            }
        });

    }

    private void CardDisplay(){

        t_view=getView().findViewById(R.id.fattext);

        String DataRead="";
        StringBuffer sbuffer=new StringBuffer();
        InputStream is=this.getResources().openRawResource(R.raw.fat);
        BufferedReader br=new BufferedReader(new InputStreamReader(is));

        if(is!=null){

            try{
                //Typeface custom_font=Typeface.createFromAsset(getActivity().getAssets(),
                        //"fonts/PAPL_.ttf");
                //t_view.setTypeface(custom_font);

                while((DataRead=br.readLine())!=null){
                    sbuffer.append(DataRead+"\n");
                }
                t_view.setText(sbuffer);
                is.close();

            }catch (Exception e){e.printStackTrace();}
        }
    }

    private void AcceptData(){

        height=getView().findViewById(R.id.enterheight);
        weight=getView().findViewById(R.id.enterweight);
        waist=getView().findViewById(R.id.enterwaist);
        hip=getView().findViewById(R.id.enterhip);
        neck=getView().findViewById(R.id.enterneck);

        Height_cm=Double.parseDouble(height.getText().toString());

        Weight_kg=Double.parseDouble(weight.getText().toString());

        Waist=Double.parseDouble(waist.getText().toString());
        Hip=Double.parseDouble(hip.getText().toString());
        Neck=Double.parseDouble(neck.getText().toString());



        if(flag==2){

            Height_cm=Height_cm*30.479999025;
            Weight_kg=Weight_kg*0.45359237;
        }

    }

    private void radiogroup1(){

        RadioGroup radioGroup1=getView().findViewById(R.id.Radiogroupfat1);
        radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int checkID) {

                switch (checkID){

                    case R.id.kg_cm:
                        flag=1;
                        break;

                    case R.id.ft_lbs:
                        flag=2;
                        break;
                }
            }
        });

    }
    private void CalculateFAT() {


        Button button=getView().findViewById(R.id.calculatefat);

        button.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                radiogroup1();
                AcceptData();

                if (Height_cm == 0.0 || Weight_kg == 0.0){

                    Toast.makeText(getActivity(),"Check the values",Toast.LENGTH_SHORT).show();
                }
                else {
                    fat = (Hip/java.lang.Math.pow((Height_cm * 0.01), 1.5))-18;


                    if (fat <= 18.5) category = "Underweight";
                    else if (18.5 < fat && fat < 24.9) category = "Acceptable";
                    else if (25.0 < fat && fat < 29.9) category = "Overweight";
                    else if (30.0 < fat) category = "Obese";

                    ans = getView().findViewById(R.id.answer);
                    ans.setText(two.format(fat)+category);
                }




            }
        });




    }   //method to calculate calorie


}
