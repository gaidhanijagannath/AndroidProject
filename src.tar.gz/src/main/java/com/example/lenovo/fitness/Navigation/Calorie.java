package com.example.lenovo.fitness.Navigation;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.IdRes;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lenovo.fitness.R;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by lenovo on 2/9/17.
 */

public class Calorie extends Fragment {
    TextView t_view;
    private double Height_cm,Height_ans;
    private double Weight_kg,Weight_ans;
    private int Age;
    private double ActivityTypeM=0.5,ActivityTypeW=0.5;
    private static EditText height,weight,age;
    private TextView TViewW;
    double kcalm,kcalw;
    private int flag=0,flag1=0;
    private static Button b1,b2;
    String height_temp,weight_temp,age_temp;
    DecimalFormat two = new DecimalFormat("#0.00");


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.calorie,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Caloric Requirement");
        CardDisplay();
        convert();
        CalculateCalorie();
    }

    private void convert() {

        b1=getView().findViewById(R.id.convert1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(),ConversionLength.class);
                getActivity().startActivity(intent);
            }
        });

        b2=getView().findViewById(R.id.convert2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(),ConversionWeight.class);
                getActivity().startActivity(intent);
            }
        });

    }

    private void radiogroup1(){

        RadioGroup radioGroup1=getView().findViewById(R.id.Radiogroup1);
        radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int checkID) {


                switch (checkID){

                    case R.id.kg_cm:
                        flag=1;
                        break;

                    case R.id.ft_lbs:
                        flag=2;
                        break;
                }
            }
        });



    }
    private boolean Validate(){
        boolean valid=true;

        if(height_temp.equals("")){
            valid=false;
             height.setError("field shouldn't be empty..");
        }
        if(weight_temp.equals("")){
            valid=false;
            weight.setError("field shouldn't be empty..");
        }
        if(age_temp.equals("")){
            valid=false;
            age.setError("field shouldn't be empty");
        }

        return valid;
    }

    private void ConvertValues(){


        Height_cm=Double.parseDouble(height_temp);
        Height_ans=Height_cm;


        Weight_kg=Double.parseDouble(weight_temp);
        Weight_ans=Weight_kg;


        Age=Integer.parseInt(age_temp);


        if(flag==2){

            Height_ans=Height_cm*30.479999025;
            Weight_ans=Weight_kg*0.45359237;
        }
//        Toast.makeText(getActivity(),String.valueOf(Height_ans), Toast.LENGTH_SHORT).show();
//        Toast.makeText(getActivity(),String.valueOf(Weight_ans), Toast.LENGTH_SHORT).show();
    }
    private void AcceptData(){


        height=getView().findViewById(R.id.enterheight);
        height_temp=height.getText().toString();

        weight=getView().findViewById(R.id.enterweight);
        weight_temp=weight.getText().toString();

        age=getView().findViewById(R.id.enterage);
        age_temp=age.getText().toString();

    }
    private void radiogroup2(){
        //choose the type of activity
        RadioGroup radioGroup2=getView().findViewById(R.id.Radiogroup2);
        radioGroup2.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, @IdRes int checkID) {


                switch (checkID){
                    case R.id.noactivity:
                        ActivityTypeM=0.5;
                        ActivityTypeW=0.5;
                        break;
                    case R.id.lightactivity:
                        ActivityTypeM=1.12;
                        ActivityTypeW=1.14;
                        break;
                    case R.id.moderateactivity:
                        ActivityTypeM=1.27;
                        ActivityTypeW=1.27;
                        break;
                    case R.id.intenseactivity:
                        ActivityTypeM=1.54;
                        ActivityTypeW=1.45;
                        break;
                }
            }


        });
    }
    private void CalculateCalorie() {



        Button button=getView().findViewById(R.id.calculatecolorie);



        button.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                radiogroup1();
                AcceptData();


                if(!Validate()){
                }
                else {

                        ConvertValues();
                        radiogroup2();

                        if(Height_cm==0.0||Weight_kg==0.0||Age==0.0){
                            Toast.makeText(getActivity().getApplicationContext(),"Check your values..",
                                    Toast.LENGTH_SHORT).show();

                        }else {


                            kcalm = (864 - 9.72 * Age +ActivityTypeM * (14.2 * Weight_ans + 503 * Height_ans * 0.01));
                            kcalw = (387 - 7.31 * Age + ActivityTypeW * (10.09 * Weight_ans + 660.7 * Height_ans * 0.01));

                            SharedPreferences preferences=getActivity().getSharedPreferences("Mydata",MODE_PRIVATE);
                            SharedPreferences.Editor editor=preferences.edit();
                            editor.putString("calorie",two.format(kcalm));
                            editor.commit();


                            TViewW = getView().findViewById(R.id.ResultAll);


                            TViewW.setText("Men:" + two.format(kcalm) + " kcals" + "\n" +
                                    "Women:" + two.format(kcalw) + " kcals");

                        }


                }
            }
        });




    }   //method to calculate calorie
    private void CardDisplay(){

        t_view=getView().findViewById(R.id.bmitext);

        String DataRead="";
        StringBuffer sbuffer=new StringBuffer();
        InputStream is=this.getResources().openRawResource(R.raw.kcals);
        BufferedReader br=new BufferedReader(new InputStreamReader(is));

        if(is!=null){

            try{

                while((DataRead=br.readLine())!=null){
                    sbuffer.append(DataRead+"\n");
                }
                t_view.setText(sbuffer);
                is.close();

            }catch (Exception e){e.printStackTrace();}
        }
    }


}

