package com.example.lenovo.fitness.Body_Workout;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.lenovo.fitness.Arm_Workout.ArmWorkout;
import com.example.lenovo.fitness.Arm_Workout.Arm_circles;
import com.example.lenovo.fitness.Arm_Workout.Mountain_climbers;
import com.example.lenovo.fitness.Arm_Workout.plank;
import com.example.lenovo.fitness.Arm_Workout.push_ups;
import com.example.lenovo.fitness.Arm_Workout.triceps_dips;
import com.example.lenovo.fitness.R;

import java.util.ArrayList;

public class BodyWorkout extends AppCompatActivity {
    Toolbar t_bar;
    ListView L_view;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_body_workout);
        ShowToolBar();
        ShowList();
    }
    private void ShowList() {
        L_view=(ListView)findViewById(R.id.full_list_view);
        L_view.setAdapter(new List_view_Adapter1(this));

        L_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {



                if(position==0){
                    Intent intent=new Intent(BodyWorkout.this,jumping_jacks.class);
                    startActivity(intent);
                }
                if(position==1){
                    Intent intent=new Intent(BodyWorkout.this,triceps_dips.class);
                    startActivity(intent);
                }
                if(position==2){
                    Intent intent=new Intent(BodyWorkout.this,Elevated_crunches.class);
                    startActivity(intent);
                }
                if(position==3){
                    Intent intent=new Intent(BodyWorkout.this,Step_ups.class);
                    startActivity(intent);
                }
                if(position==4){
                    Intent intent=new Intent(BodyWorkout.this,Running_in_place.class);
                    startActivity(intent);
                }
            }
        });
    }

    private void ShowToolBar(){
        t_bar=(Toolbar)findViewById(R.id.includefull);
        setSupportActionBar(t_bar);

        if(getSupportActionBar()!=null){

            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle("Body Workout");
        }


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}

class CompositeObject1{
    String exercise_name,Reps;
    int images;

    CompositeObject1(String exercise_name,String Reps,int images){
        this.exercise_name=exercise_name;
        this.Reps=Reps;
        this.images=images;
    }

}
class List_view_Adapter1 extends BaseAdapter {

    ArrayList<CompositeObject1> List;

    Context context;
    List_view_Adapter1(Context c){

        context=c;
        List=new ArrayList<CompositeObject1>();
        Resources res=c.getResources();
        String Arm_exercises[]=res.getStringArray(R.array.fullExercises);
        String Reps[]=res.getStringArray(R.array.MaxReps1);
        int images[]={R.drawable.dumbbell,R.drawable.dumbbell,R.drawable.dumbbell,
                R.drawable.dumbbell,R.drawable.dumbbell};

        for (int i=0;i<5;i++){

            List.add(new CompositeObject1(Arm_exercises[i],Reps[i],images[i]));
        }
    }

    @Override
    public int getCount() {
        return List.size();
    }

    @Override
    public Object getItem(int i) {
        return List.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row=inflater.inflate(R.layout.single_row_layout,viewGroup,false);

        TextView exercise=row.findViewById(R.id.Exs);
        TextView reps=row.findViewById(R.id.Reps);
        ImageView image=row.findViewById(R.id.image_View);

        CompositeObject1 comp=List.get(i);

        exercise.setText(comp.exercise_name);
        reps.setText(comp.Reps);
        image.setImageResource(comp.images);

        return row;
    }
}
