package com.example.lenovo.fitness;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by lenovo on 1/10/17.
 */

public class CalendarDatabase extends SQLiteOpenHelper {



    private static final int DATABASE_VERSION=1;
    private static final String DATABASE_NAME="Calendar.db";
    private static final String column_ID ="id";
    private static final String TABLE_NAME="timestats";
    private static final String column_start="start";
    private static final String column_end="end";
    SQLiteDatabase sqLiteDatabase;


    private static final String query="CREATE table timestats (id INT PRIMARY KEY AUTO_INCREMENT,"+
            "start TIME not null,"+"end TIME not null)";

    public CalendarDatabase(Context context) {
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(query);
        this.sqLiteDatabase=sqLiteDatabase;

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int old_version, int new_version) {
        String drop="DROP TABLE IF EXISTS "+TABLE_NAME;
        sqLiteDatabase.execSQL(drop);
        this.onCreate(sqLiteDatabase);
    }

    public void InsertStartTime(){

    }
    public void InsertEndTime(){

    }

    public String GetTimeDifference(){
        String Time=null;

        return Time;
    }
}
