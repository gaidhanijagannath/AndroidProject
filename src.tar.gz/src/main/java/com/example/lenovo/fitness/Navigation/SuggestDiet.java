package com.example.lenovo.fitness.Navigation;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lenovo.fitness.R;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by lenovo on 6/10/17.
 */

public class SuggestDiet extends Fragment {
    TextView _calorie,_fat,_bmi,_mr;
    double calorie_,fat_,bmi_,mr_;

    Button suggest;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.suggestdiet,null,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Suggest Diet");

        SetNull();
        AssignStats();
        suggestdiet();




    }

    private void SetNull() {

        _bmi=getView().findViewById(R.id.Bmi);
        _calorie=getView().findViewById(R.id.Calorie);
        _fat=getView().findViewById(R.id.fat);
        _mr=getView().findViewById(R.id.Mr);


        _bmi.setText("0.00");
        _calorie.setText("0.00");
        _fat.setText("0.00");
        _mr.setText("0.00");
    }

    private void suggestdiet() {

        suggest=getView().findViewById(R.id.suggest_button);

        suggest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment fragment=null;

                if(bmi_<=20||fat_<=18.5){
                    fragment=new BulkingDiet();
                    FragmentTransaction ft=getActivity().getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.frame_layout,fragment).commit();

                }else{

                    fragment=new CuttingDiet();
                    FragmentTransaction ft=getActivity().getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.frame_layout,fragment).commit();
                }

            }
        });

    }

    private void AssignStats() {

        SharedPreferences get=this.getActivity().getSharedPreferences("Mydata",MODE_PRIVATE);
        String bmi=get.getString("bmi","");
        String fat=get.getString("fat","");
        String mr=get.getString("mr","");
        String calorie=get.getString("calorie","");


        if(bmi.equals("")&&calorie.equals("")&&fat.equals("")&&mr.equals("")){
            Toast.makeText(getActivity(), "calculate fitness status", Toast.LENGTH_SHORT).show();

        }else {

            if(bmi.equals("")){

                Toast.makeText(getActivity(), "calculate bmi", Toast.LENGTH_SHORT).show();
            }else{

                _bmi.setText(bmi);
                bmi_=Double.parseDouble(bmi);

            }

            if(fat.equals("")){

                Toast.makeText(getActivity(), "Calculate fat%", Toast.LENGTH_SHORT).show();
            }else{


                _fat.setText(fat);
                fat_=Double.parseDouble(fat);

            }

            if(calorie.equals("")){

                Toast.makeText(getActivity(), "Calculate Calorie", Toast.LENGTH_SHORT).show();
            }else{


                _calorie.setText(calorie);
                calorie_=Double.parseDouble(calorie);

            }

            if(mr.equals("")){

                Toast.makeText(getActivity(), "Calculate MR", Toast.LENGTH_SHORT).show();
            }else{


                _mr.setText(mr);
                mr_=Double.parseDouble(mr);

            }
        }
    }
}
